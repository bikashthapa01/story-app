# Tale Tale : A Story Telling Android App Projects


### 1. RecyclerView and CardView 

![RecyclerView](https://i.imgur.com/OADjcs5.png)



### 2. DetailView 

![DetailVew](https://i.imgur.com/xZQ49f2.png)
